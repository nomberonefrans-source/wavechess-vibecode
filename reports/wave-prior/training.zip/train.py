import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,subprocess,sys,hashlib
from pathlib import Path
import numpy as np
from scipy.special import softmax
rows=[json.loads(l) for f in sorted(Path('.').glob('labels?.jsonl')) for l in open(f)]
rows.sort(key=lambda r:r[1])
X=[];Y=[];idx=[];sz=[];valid=[]
def convert(row,line):
    op,fen,labels=row
    tokens=line.split();moves=tokens[::44];feats=np.array(tokens).reshape(-1,44)[:,1:].astype('f')
    cp=np.array([v for _,v in labels]); weights=softmax((cp-cp.max()).clip(-500,0)/65.+np.array([0,-0.35,-0.7])[:len(cp)])
    probs=np.zeros(len(moves),'f')
    for (m,_),y in zip(labels,weights):probs[moves.index(m)]=y
    return feats,probs,moves
for start in range(0,len(rows),100):
    rr=rows[start:start+100]
    lines=subprocess.run(['./export'],input='\n'.join(r[1] for r in rr)+'\n',text=True,stdout=subprocess.PIPE,check=True).stdout.splitlines()
    for r,line in zip(rr,lines):
        x,y,m=convert(r,line);idx.append(len(X));X.extend(x);Y.extend(y);sz.append(len(m))
        valid.append(int(hashlib.sha256(r[0].encode()).hexdigest()[:8],16)%5==0)
X=np.array(X,'f');Y=np.array(Y,'f');sz=np.array(sz);off=np.array(idx);valid=np.array(valid)
mask=np.repeat(~valid,sz);mu=X[mask].mean(0);scale=X[mask].std(0).clip(.1);X=(X-mu)/scale
rng=np.random.default_rng(721901)
A=rng.normal(0,.19,(X.shape[1],12)).astype('f');bias=np.zeros(12,'f');O=rng.normal(0,.15,12).astype('f');params=[A,bias,O];mt=[z*0 for z in params];vt=[z*0 for z in params];step=0
def measure():
    z=np.maximum(X@A+bias,0)@O
    ranks=[]
    for i in np.flatnonzero(valid):
        lo=off[i]; hi=lo+sz[i]; order=np.argsort(-z[lo:hi],kind='stable')
        ranks.append(1+np.where(order==np.argmax(Y[lo:hi]))[0][0])
    return [float(np.mean(np.array(ranks)<=k)) for k in (1,5,8)]
for ep in range(35):
    perm=rng.permutation(np.flatnonzero(~valid))
    for ix in np.array_split(perm,max(1,len(perm)//96)):
        ns=sz[ix];beg=np.r_[0,np.cumsum(ns)[:-1]]
        ii=np.arange(ns.sum())+np.repeat(off[ix]-beg,ns)
        x=X[ii];h=np.maximum(x@A+bias,0);z=h@O
        ex=np.exp(z-np.repeat(np.maximum.reduceat(z,beg),ns))
        dz=(ex/np.repeat(np.add.reduceat(ex,beg),ns)-Y[ii])/len(ix)
        dh=(dz[:,None]*O)*(h>0)
        grads=[x.T@dh+0.0007*A,dh.sum(0),h.T@dz+0.0007*O]
        step+=1
        for p,g,m,v in zip(params,grads,mt,vt):
            m*=.9;m+=.1*g;v*=.999;v+=.001*g*g
            p-=.003*(m/(1-.9**step))/(np.sqrt(v/(1-.999**step))+1e-8)
result=measure()
print('positions',len(rows),sum(~valid),sum(valid),'top1/5/8',result,flush=True)
def fmt(x):return '['+', '.join(f'{a:.8f}' for a in x)+']'
file=Path('retrained_weights.rs')
file.write_text('// Trained relative-move scores. Input normalization is folded into the first layer.\n'+
'const BIAS: [f32; 12] = '+fmt(bias-(mu/scale)@A)+';\nconst OUTPUT: [f32; 12] = '+fmt(O)+';\nconst WEIGHTS: [[f32; 12]; FEATURES] = [\n'+''.join('    '+fmt(a)+',\n' for a in A/scale[:,None])+'];\n')
