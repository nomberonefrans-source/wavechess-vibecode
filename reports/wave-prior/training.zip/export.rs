#![allow(dead_code)]
#[path="../src/board.rs"] mod board;
#[path="../src/geometry.rs"] mod geometry;
#[path="../src/wave.rs"] mod wave;
#[path="../src/params.rs"] mod params;
#[path="../src/spectral.rs"] mod spectral;
#[path="../src/policy.rs"] mod policy;
use std::io::{self,BufRead};
fn main(){
 for s in io::stdin().lock().lines().map_while(Result::ok){
    let b=board::Board::from_fen(&s).unwrap();
    let w=wave::WaveField::compute_with(&b,&params::Ps::load());
    let moves=b.legal_moves();
    for &m in &moves.m[..moves.n] {
        let next=b.make(m);
        let x=policy::features(&b,&w,m,&next,policy::contacts(&b,m.from as usize),next.in_check());
        print!("{} ",m.to_uci());
        for v in x {print!("{v:.4} ");}
    }
    println!();
 }
}
