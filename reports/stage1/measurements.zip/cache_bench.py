import json,pathlib,subprocess,time,statistics
out={}
for name,exe in [('base','baseline'),('stage1','repo/target/release/wavechess')]:
    p=subprocess.Popen([str(pathlib.Path(exe).resolve()),'uci'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    def barrier(cmd):
        start=time.perf_counter()
        p.stdin.write(cmd+'\nisready\n')
        p.stdin.flush()
        while True:
            line=p.stdout.readline()
            if not line:raise RuntimeError('engine exited')
            if line.strip()=='readyok':return round((time.perf_counter()-start)*1000,3)
    barrier('setoption name Threads value 2\nsetoption name Hash value 256')
    clear=[barrier('setoption name Clear Hash') for _ in range(9)]
    out[name]={'clear_ms':clear,'median_ms':statistics.median(clear)}
    p.communicate('quit\n')
print(json.dumps(out,indent=2))
